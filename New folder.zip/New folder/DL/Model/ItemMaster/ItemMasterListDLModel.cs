﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLibrary.Model.ItemMaster
{
    public class ItemMasterListDLModel
    {
        public List<ItemMasterDLModel> ItemasterList { get; set; }
    }
}
