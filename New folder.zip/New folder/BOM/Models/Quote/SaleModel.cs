﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnlineBOM.Models
{
    public class SaleModel
    {
        public string ID { get; set; }
        public string SaleType { get; set; }
    }
}