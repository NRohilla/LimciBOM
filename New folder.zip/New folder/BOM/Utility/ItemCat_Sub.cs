﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication3.Utility
{
    public class ItemCat_Sub
    {
        public string Category { get; set; }
        public int CategoryOrder { get; set; }
        public string SubCategory { get; set; }
        public int SubCategoryOrder { get; set; }
    }
}