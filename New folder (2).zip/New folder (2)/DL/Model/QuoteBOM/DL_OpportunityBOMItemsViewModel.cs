﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLibrary.Model.QuoteBOM
{

    public class DL_OpportunityBOMItemsViewModel
    {
        public List<DL_OpportunityBOMItem> BOMListViewModel { get; set; }
    }

}
